package com.ohgiraffers.forepeproject.post.query.infrastructure.repository;

public class Repository {
}
