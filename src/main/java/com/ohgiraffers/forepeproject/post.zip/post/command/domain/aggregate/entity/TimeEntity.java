package com.ohgiraffers.forepeproject.post.command.domain.aggregate.entity;

public class TimeEntity {
}
