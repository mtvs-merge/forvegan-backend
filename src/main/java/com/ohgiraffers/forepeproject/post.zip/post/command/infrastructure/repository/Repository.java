package com.ohgiraffers.forepeproject.post.command.infrastructure.repository;

public class Repository {
}
