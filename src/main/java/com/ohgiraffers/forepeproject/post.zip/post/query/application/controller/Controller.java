package com.ohgiraffers.forepeproject.post.query.application.controller;

public class Controller {
}
