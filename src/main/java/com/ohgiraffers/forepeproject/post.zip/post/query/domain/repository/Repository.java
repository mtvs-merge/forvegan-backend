package com.ohgiraffers.forepeproject.post.query.domain.repository;

public class Repository {
}
