package com.ohgiraffers.forepeproject.post.command.domain.aggregate.entity.enumType;

import org.hibernate.type.EnumType;

public enum ResponesEnum {
    SUCCESS,              // 성공
    FAILURE               // 실패
}
