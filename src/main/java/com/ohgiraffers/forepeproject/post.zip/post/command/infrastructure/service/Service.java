package com.ohgiraffers.forepeproject.post.command.infrastructure.service;

public class Service {
}
