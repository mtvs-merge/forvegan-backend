package com.ohgiraffers.forepeproject.post.query.domain.service;

public class Service {
}
