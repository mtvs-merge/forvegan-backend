package com.ohgiraffers.forepeproject.post.command.domain.service;


public class PostService {

}
