package com.ohgiraffers.forepeproject.post.query.application.dto;

public class DTO {
}
