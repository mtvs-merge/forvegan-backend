package com.ohgiraffers.forepeproject.post.query.domain.entity;




public class PostEntity {


    public static Object builder() {
        return null;
    }
}
