package com.ohgiraffers.forepeproject.post.query.infrastructure.service;

public class Service {
}
